

/**
 * @author Natty
 * @version 1.0
 * @created 12-Jul-2023 10:25:15 PM
 */
public class payment {

	public string amount;
	public string cardNumber;
	public int id;

	public payment(){

	}

	public void finalize() throws Throwable {

	}

	public add(){

	}

	public update(){

	}

}