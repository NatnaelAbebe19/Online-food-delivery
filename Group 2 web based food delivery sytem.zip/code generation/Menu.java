

/**
 * @author Natty
 * @version 1.0
 * @created 12-Jul-2023 10:26:18 PM
 */
public class Menu {

	public string details;
	protected int id;
	public string listOfMeal;
	public Dish/Meal m_Dish/Meal;
	public Customer m_Customer;

	public Menu(){

	}

	public void finalize() throws Throwable {

	}

	public add(){

	}

	public update(){

	}

}