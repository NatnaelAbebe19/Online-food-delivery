

/**
 * @author Natty
 * @version 1.0
 * @created 12-Jul-2023 10:25:05 PM
 */
public class Delivery {

	public string address;
	public string date;
	protected int id;
	public string name;
	public payment m_payment;
	public Enumeration1 m_Enumeration1;

	public Delivery(){

	}

	public void finalize() throws Throwable {

	}

	public update(){

	}

}