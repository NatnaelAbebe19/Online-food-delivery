

/**
 * @author Natty
 * @version 1.0
 * @created 12-Jul-2023 10:25:21 PM
 */
public class Order {

	public int details;
	protected int id;
	public string ordertype;
	public Delivery m_Delivery;
	public Dish/Meal m_Dish/Meal;

	public Order(){

	}

	public void finalize() throws Throwable {

	}

	public processDebit(){

	}

}