

/**
 * @author Natty
 * @version 1.0
 * @created 12-Jul-2023 10:25:31 PM
 */
public class Customer extends Admin {

	public string address;
	protected int cardnum;
	public Order m_Order;
	public payment m_payment;

	public Customer(){

	}

	public void finalize() throws Throwable {
		super.finalize();
	}

	protected int create(){
		return 0;
	}

}