

/**
 * @author Natty
 * @version 1.0
 * @created 12-Jul-2023 10:26:24 PM
 */
public class Admin {

	public int age;
	public int contactNum;
	protected int id;
	public string name;
	private string password;
	private string username;

	public Admin(){

	}

	public void finalize() throws Throwable {

	}

	public create(){

	}

	public update(){

	}

}