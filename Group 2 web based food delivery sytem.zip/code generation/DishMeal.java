

/**
 * @author Natty
 * @version 1.0
 * @created 12-Jul-2023 10:25:44 PM
 */
public class Dish/Meal {

	protected int id;
	public string names;
	public int price;

	public Dish/Meal(){

	}

	public void finalize() throws Throwable {

	}

	public add(){

	}

	public update(){

	}

}